#ifndef __AD7175_H__
#define __AD7175_H__

#include <stdio.h>
#include <string.h>
#include "drivers/bus/spi.h"


enum {
    MP_AD7175_IOCTL_DEFAULT,
};

typedef struct _st_reg
{
    uint8_t addr;
    uint32_t value;
    uint8_t size;
} st_reg;
/*! AD7175 registers list*/
typedef enum
{
    Status_Register = 0x00,
    ADC_Mode_Register,
    Interface_Mode_Register,
    REGCHECK,
    Data_Register,
    GPIOCON,
    ID_st_reg,
    CH_Map_1,
    CH_Map_2,
    CH_Map_3,
    CH_Map_4,
    Setup_Config_1,
    Setup_Config_2,
    Setup_Config_3,
    Setup_Config_4,
    Filter_Config_1,
    Filter_Config_2,
    Filter_Config_3,
    Filter_Config_4,
    Offset_1,
    Offset_2,
    Offset_3,
    Offset_4,
    Gain_1,
    Gain_2,
    Gain_3,
    Gain_4,
    Communications_Register,
    AD7175_REG_NO
}AD7175_registers;
/*! Array holding the info for the AD7175 registers - address, initial value, size */
st_reg AD7175_regs[] =
{
    {0x00, 0x00,   1},  //Status_Register
    {0x01, 0x8000, 2},  //ADC_Mode_Register
    {0x02, 0x0000, 2},  //Interface_Mode_Register
    {0X03, 0x0000, 3},  //REGCHECK
    {0x04, 0x0000, 3},  //Data_Register
    {0x06, 0x0800, 2},  //GPIOCON
    {0x07, 0x0000, 2},  //ID_st_reg
    {0x10, 0x8004, 2},  //CH_Map_1
    {0x11, 0x0001, 2},  //CH_Map_2
    {0x12, 0x0001, 2},  //CH_Map_3
    {0x13, 0x0001, 2},  //CH_Map_4
    {0x20, 0x0320, 2},  //Setup_Config_1
    {0x21, 0x0320, 2},  //Setup_Config_2
    {0x22, 0x0320, 2},  //Setup_Config_3
    {0x23, 0x0320, 2},  //Setup_Config_4
    {0x28, 0x0500, 2},  //Filter_Config_1
    {0x29, 0x0500, 2},  //Filter_Config_2
    {0x2a, 0x0500, 2},  //Filter_Config_3
    {0x2b, 0x0500, 2},  //Filter_Config_4
    {0x30, 0x800000, 3},    //Offset_1
    {0x31, 0x800000, 3},    //Offset_2
    {0x32, 0x800000, 3},    //Offset_3
    {0x33, 0x800000, 3},    //Offset_4
    {0x38, 0x500000, 3},    //Gain_1
    {0x39, 0x500000, 3},    //Gain_2
    {0x3a, 0x500000, 3},    //Gain_3
    {0x3b, 0x500000, 3},    //Gain_4
    {0xFF, 0x500000, 1}     //Communications_Register
};

st_reg AD7175_regs[AD7175_REG_NO];


typedef enum{
    RATE_250000HZ=0x00,
    RATE_125000HZ,
    RATE_62500HZ,
    RATE_50000HZ,
    RATE_31250HZ,
    RATE_25000HZ,
    RATE_15625HZ,
    RATE_10000HZ,
    RATE_5000HZ,
    RATE_2500HZ,
    RATE_1000HZ,
    RATE_500HZ,
    RATE_397P5HZ,
    RATE_200HZ,
    RATE_100HZ,
    RATE_59P92HZ,
    RATE_49P96HZ,
    RATE_20HZ,
    RATE_16P66HZ,
    RATE_10HZ,
    RATE_5HZ,
    AD7175_RATES_NO
}AD7175_rates;

typedef struct _sample_rate_t{
    AD7175_rates value;
    float rate;
}sample_rate_t;

sample_rate_t AD7175_rates_table[] = {
    {RATE_250000HZ, 250000},  //250kHz samplerates
    {RATE_125000HZ, 125000},  //125kHz samplerates
    {RATE_62500HZ, 62500},  //62.5kHz samplerates
    {RATE_50000HZ, 50000},  //50kHz samplerates
    {RATE_31250HZ, 31250},  //31.25kHz samplerates
    {RATE_25000HZ, 25000},  //25kHz samplerates
    {RATE_15625HZ, 15625},  //15.625kHz samplerates
    {RATE_10000HZ, 10000},  //10kHz samplerates
    {RATE_5000HZ, 5000},  //5kHz samplerates
    {RATE_2500HZ, 2500},  //2.5kHz samplerates
    {RATE_1000HZ, 1000},  //1kHz samplerates
    {RATE_500HZ, 500},  //500Hz samplerates
    {RATE_397P5HZ, 397.5},  //397.5Hz samplerates
    {RATE_200HZ, 200},  //200Hz samplerates
    {RATE_100HZ, 100},  //100Hz samplerates
    {RATE_59P92HZ, 59.92},  //59.92Hz samplerates
    {RATE_49P96HZ, 49.96},  //49.96Hz samplerates
    {RATE_20HZ, 20},  //20Hz samplerates
    {RATE_16P66HZ, 16.66},  //16.66Hz samplerates
    {RATE_10HZ, 10},  //10Hz samplerates
    {RATE_5HZ, 5},  //5Hz samplerates
};
sample_rate_t AD7175_rates_table[AD7175_RATES_NO];


typedef enum {
    ch0=0x00,
    ch1,
    ch2,
    ch3,
}AD7175_channel;

typedef struct{
    uint16_t value;
    union {
        uint8_t high;
        uint8_t low;
    }u8;
} c_u16_t;

#define GAIN    0x555555
#define OFFSET  0x800000
#define RESOLUTION  24
#define AD7175_CHIP_ID  0x0cd0
#define DEFAULT_TIMEOUT_MS 400

#define MP_PASS      0
#define MP_FAIL     -1

//#define DEFAULE_TIMEOUT 1
//#define DEFAULT_TIMEOUT_MS      400
//#define DEFAULT_DELAY           0.001
//
//#define ADC_MODE_REG_ADDR           0x01
//#define DEFAULT_DELAY           0.001
//
//
#define CLOCKSEL_MASK 0x0c

typedef enum{
    unipolar = 0x00,
    bipolar = 0x01,
}POLARS;


typedef enum{
    disable=0x00,
    enable=0x0f,
}BUFFERS;



typedef enum{
    external=0x00,
    internal=0x02,
    AVDD_AVSS=0x03,
}REFERENCES;

typedef enum{
    AIN0=0x00,
    AIN1=0x01,
    AIN2=0x02,
    AIN3=0x03,
    AIN4=0x04,
    Temp_p=0x11,
    Temp_n=0x12,
    AVDD1=0x13,
    AVSS=0x14,
    REF_p=0x15,
    REF_n=0x16,
}AINS;

typedef enum{
    c_internal=0x00,
    output=0x04,
    c_external=0x08,
    crystal=0x0c

}CLOCKSEL;

typedef struct{
    AINS p;
    AINS n;
}adc_ch;


typedef struct{
    mp_obj_base_t base;
    int mvref;
    POLARS code_polar;
    REFERENCES reference;
    BUFFERS buffer_flag;
    CLOCKSEL clock;
    adc_ch ch[2];
    unsigned char resolution;
    AD7175_rates rate;
    mp_hal_pin_obj_t cs;
    mp_soft_spi_obj_t spi;
}ad7175_handler;

extern const mp_obj_type_t ad7175_type;

void ad7175_init(ad7175_handler *self, mp_hal_pin_obj_t cs);
void ic_init(ad7175_handler *self);
void write_register(ad7175_handler *self, uint8_t reg_addr, uint8_t *reg_data, size_t len);
void read_register(ad7175_handler *self, uint8_t reg_addr, void *recv_buf, size_t len);
void reset(ad7175_handler *self);
void set_setup_register(ad7175_handler *self, AD7175_channel ch, POLARS code_polar, REFERENCES reference,  BUFFERS buffer_flag);
int is_communication_ok(ad7175_handler *self, uint32_t timeout);
//timeout us
int8_t wait_for_ready(ad7175_handler *self, uint32_t timeout);
int8_t wait_for_ready_no_timeout(ad7175_handler *self);
float get_sample_rate(ad7175_handler *self);
void set_sample_rate(ad7175_handler *self, AD7175_channel ch, AD7175_rates rate);
void set_channel_state(ad7175_handler *self, AD7175_channel ch, char *state);
void select_single_channel(ad7175_handler *self, AD7175_channel ch);
float read_volt(ad7175_handler *self, AD7175_channel ch);

void cs_test(ad7175_handler *self);


#endif
