/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-19     Administrator       the first version
 */
#include "py/mphal.h"
#include "py/runtime.h"
#include "AD7175.h"


// ad7175 ic driver
STATIC uint8_t get_cmd(uint8_t cmd, uint8_t wirte_bit);
STATIC int ad7175_ioctl(void *self_in, uint32_t cmd);

STATIC void reverse(uint8_t a[], uint8_t len)
{
    uint8_t left=0;
    uint8_t right = len - 1;
    uint8_t b;
    while (left < right)
    {
        b = a[right];
        a[right] = a[left];
        a[left] = b;
        left++;
        right --;
    }
}

STATIC uint8_t get_cmd(uint8_t cmd, uint8_t wirte_bit)
{
    uint8_t _cmd;
    if (wirte_bit == 0)
    {
        _cmd = 0x3f & cmd;
    }else{
        _cmd = (0x3f & cmd)|(0x01 << 6);
    }
    return _cmd;
}

STATIC int ad7175_ioctl(void *self_in, uint32_t cmd) {
    ad7175_handler *self = (ad7175_handler *)self_in;
    switch (cmd) {
        case MP_AD7175_IOCTL_DEFAULT:
            self->resolution = RESOLUTION;
            self->mvref = 5000.0;
            self->code_polar = bipolar;
            self->reference = external;
            self->buffer_flag = enable;
            self->clock = c_internal;
            self->rate = RATE_5HZ;
            self->ch[0].p = AIN0;
            self->ch[0].n = AIN1;
            self->ch[1].p = AIN2;
            self->ch[1].n = AIN3;
            break;
    }
    return 0;
}

STATIC float value_2_mvolt(ad7175_handler *self, float code)
{
    float volt;
    if (self->code_polar == bipolar){
        volt = (float)(code - (1 << (self->resolution -1))) * 0x400000 / GAIN;
//        volt = (tmp + (OFFSET - 0x800000)) / (1 << self->resolution -1) * self->mvref / 0.75;
    }else {
        volt = code /2.0*0x400000/GAIN;
    }
    return (volt + (OFFSET - 0x800000)) / (1 << (self->resolution -1)) * self->mvref /0.75;
}

STATIC sample_rate_t search_sample_rate(ad7175_handler *self, float sp)
{
    float min= (1 << 30)-1;
    int8_t index=0;
    sample_rate_t t;
    t = AD7175_rates_table[0];
    float diff=0;
    if (sp >= t.rate)
    {
        return t;
    }
    for (int8_t i=0; i< AD7175_RATES_NO; i++){
        t = AD7175_rates_table[i];
        diff = t.rate - sp;
        if (diff < 0){
            diff = -diff;
        }
        if (diff < min){
            min = diff;
            index = i;
        }
    }
    t = AD7175_rates_table[index];
    return t;
}

//int mvref, POLARS code_polar, REFERENCES reference,  BUFFERS buffer_flag, CLOCKSEL clock
void ad7175_init(ad7175_handler *self, mp_hal_pin_obj_t cs, mp_hal_pin_obj_t status)
{
    self->status = status;
    self->cs = cs,
    // config the cs pin
    mp_hal_pin_output(self->cs);
    mp_hal_pin_write(self->cs, 1);

    //config the status pin
    mp_hal_pin_config_speed(self->status, MP_HAL_PIN_SPEED_VERY_HIGH);
    mp_hal_pin_config(self->status, MP_HAL_PIN_MODE_INPUT, MP_HAL_PIN_PULL_UP, 0);
    // mp_hal_pin_config(self->status, MP_HAL_PIN_MODE_INPUT, MP_HAL_PIN_PULL_UP, 0);
    // printf("status: %d\n", mp_hal_pin_read(self->status));
    ad7175_ioctl(self, MP_AD7175_IOCTL_DEFAULT);
    reset(self);
    ic_init(self);
}

void ic_init(ad7175_handler *self)
{
    set_setup_register(self, ch0, bipolar, external, enable);
    set_setup_register(self, ch1, bipolar, external, enable);
}

void write_register(ad7175_handler *self, uint8_t reg_addr, uint8_t *reg_data, size_t len)
{
    if (reg_addr == 0x00 || reg_addr == 0x03 || reg_addr == 0x04)
    {
        return;
    }
    uint8_t wd_data[len + 1];
    memset(wd_data, 0, len + 1);
    wd_data[0] = get_cmd(reg_addr, 0);
    // reverse(reg_data, len);
    memcpy(&wd_data[1], reg_data, len);
    mp_hal_pin_write(self->cs, 0);
    spi_proto.transfer(self->spi, len+1, wd_data, NULL);
    mp_hal_pin_write(self->cs, 1);
}

void read_register(ad7175_handler *self, uint8_t reg_addr, void *recv_buf, size_t len)
{
    uint8_t wd_data[len + 1];
    memset(wd_data, 0, len + 1);
    wd_data[0] = get_cmd(reg_addr, 1);
    mp_hal_pin_write(self->cs, 0);
    spi_proto.transfer(self->spi, 1, &wd_data[0], NULL);
    spi_proto.transfer(self->spi, len, NULL, recv_buf);
    mp_hal_pin_write(self->cs, 1);
}

void reset(ad7175_handler *self)
{
    uint8_t reset_data[12];
    memset(reset_data, 0xff, 12);
    mp_hal_pin_write(self->cs, 0);
    spi_proto.transfer(self->spi, 12, reset_data, NULL);
    mp_hal_pin_write(self->cs, 1);
    mp_hal_delay_ms(1);
}

void set_setup_register(ad7175_handler *self, AD7175_channel ch, POLARS code_polar, REFERENCES reference,  BUFFERS buffer_flag)
{
    st_reg reg_t =  AD7175_regs[Setup_Config_1 + ch];
    uint16_t value = 0;
    uint8_t rd_data[2];
    self->code_polar = code_polar;
    self->reference = reference;
    self->buffer_flag = buffer_flag;
    value |= self->code_polar <<12 | self->buffer_flag <<8 | self->reference <<4;
    rd_data[0] = value >> 8;
    rd_data[1] = value & 0x00ff;
    write_register(self, reg_t.addr, rd_data, 2);
    read_register(self, reg_t.addr, rd_data, reg_t.size);

}

uint8_t id_detect(ad7175_handler *self, uint32_t timeout)
{
    st_reg reg_t =  AD7175_regs[ID_st_reg];
    uint8_t rd_data[2]={0};
    int8_t ready = 0;
    uint16_t id;
    mp_hal_pin_write(self->cs, 1);
    while (!ready && --timeout)
    {
        read_register(self, reg_t.addr, rd_data, reg_t.size);
        id = (rd_data[0] << 8 | rd_data[1]);
        printf("id is: %04x\n", id);
        ready =  ((id & 0xfff0) == 0x0cd0);
        if (!ready)
        {
            reset(self);

        }
    }
    return timeout ? MP_PASS : MP_FAIL;
}

//timeout us
int8_t wait_for_ready(ad7175_handler *self, uint32_t timeout, bool cs_control)
{
    uint8_t wd_data[2] = {0};
    uint32_t rate;
    wd_data[0] = get_cmd(Status_Register, 1);
    int8_t ready = 1;
    rate = (uint32_t) 1000000.0 / AD7175_rates_table[self->rate].rate;
    if (cs_control){
         mp_hal_pin_write(self->cs, 0);
    }
    while(ready && timeout)
    {
        spi_proto.transfer(self->spi, 2, wd_data, wd_data);
        ready = (wd_data[1] & 0x80) == 0;
        mp_hal_delay_us(rate);
        timeout -= rate;
    }
    if (cs_control){
        mp_hal_pin_write(self->cs, 1);
    }
    return timeout ? 0 : -1;
}

/***************************************************/
/*just for test*/
int8_t wait_for_ready_no_timeout(ad7175_handler *self)
{
    uint8_t wd_data[2] = {0, 0};
    uint8_t ready;
    wd_data[0] = get_cmd(Status_Register, 1);
    mp_hal_pin_write(self->cs, 0);
    spi_proto.transfer(self->spi, 2, wd_data, wd_data);
    mp_hal_pin_write(self->cs, 1);
    ready = (wd_data[1] & 0x80) == 0;
    return ready;
}

float get_sample_rate(ad7175_handler *self)
{
    return AD7175_rates_table[self->rate].rate;
}

bool set_sample_rate(ad7175_handler *self, AD7175_channel ch, AD7175_rates rate)
{
    uint8_t rd_data[2];
    AD7175_rates before_rate;
    st_reg reg_t =  AD7175_regs[Filter_Config_1 + ch];
    before_rate = self->rate;
    self->rate = rate;
    read_register(self, reg_t.addr, rd_data, reg_t.size);
    printf("read_rate: %02x,%02x\n", rd_data[0], rd_data[1]);
    rd_data[1] = ((rd_data[1]) & (~0x1f))| self->rate;
    printf("write_rate: %02x,%02x\n", rd_data[0], rd_data[1]);
    write_register(self, reg_t.addr, rd_data, reg_t.size);
    read_register(self, reg_t.addr, rd_data, reg_t.size);
    if (self->rate = (rd_data[1] & 0x1f)){
        return true;
    }
    self->rate = before_rate;
    return false;
}


void set_channel_state(ad7175_handler *self, AD7175_channel ch, char *state)
{
    st_reg reg_t = reg_t = AD7175_regs[CH_Map_1 + ch];
    c_u16_t t;
    t.value = 0;
    if (strcmp(state, "enable"))
    {
        t.value |= 0x01 << 15;
    }
    t.value |= ch << 12;
    t.value |= self->ch[ch].p << 5;
    t.value |= self->ch[ch].n;
    reverse(t.reg, 2);
    write_register(self, reg_t.addr, (uint8_t*) &t.value, reg_t.size);
}

void select_single_channel(ad7175_handler *self, AD7175_channel ch)
{
    set_channel_state(self, ch, "disable");
    set_channel_state(self, ch, "enable");
}

float read_volt(ad7175_handler *self, AD7175_channel ch)
{
    float data=0;
    uint8_t timeout = 1000;
    uint8_t wd_data[3];
    c_u16_t wd_data_16;
    st_reg reg_t = AD7175_regs[Interface_Mode_Register];
    // set setup register
    ic_init(self);
    //TODO: may be &reg_t.value is not right ,need test it 
    write_register(self, reg_t.addr, &reg_t.value, reg_t.size);
    select_single_channel(self, ch);

    wd_data_16.value = 0x0000;
    wd_data_16.value = ((wd_data_16.value & 0xff0f) | 0x0010);
    wd_data_16.value &= ~CLOCKSEL_MASK;
    wd_data_16.value |= self->clock;
    reg_t = AD7175_regs[ADC_Mode_Register];
    reverse(wd_data_16.reg, 2);
    write_register(self, reg_t.addr, &wd_data_16.reg[0], reg_t.size);
    // waite 400ms until convert is finished, the max timeout is 400ms
    while(timeout--)
    {
        if (mp_hal_pin_read(self->status) == 0){
            break;
        }
        mp_hal_delay_ms(1);
    }
    if (!timeout){
        // we need raise the timeout fail here
        mp_raise_ValueError(MP_ERROR_TEXT("read_volt timeout: 400000us"));
        return -99999999.0;
    }
    reg_t = AD7175_regs[Data_Register];
    // need test u8 *reg and int u32 *reg
    read_register(self, reg_t.addr, wd_data, reg_t.size);
    if (self->resolution == 24)
    {
        data = wd_data[0]<< 16| wd_data[1]<<8| wd_data[2];
    }
    return value_2_mvolt(self, data);
}

void datalogger(ad7175_handler *self, AD7175_channel ch, AD7175_rates rate, uint32_t nums)
{
    c_u16_t wd_data_16;

    uint8_t wd_data[4]={0};
    uint32_t delay_us;
    uint32_t timeout=0;
    //malloc enough size to save the raw data;
    c_u32_t  *raw_data = m_new(c_u32_t, nums);
    // memset(raw_data, 0, nums);
    // set setup register
    ic_init(self);
    //default is the continuse convert mode
    // set this mode first
    st_reg reg_t = AD7175_regs[ADC_Mode_Register];
    //TODO: may be &reg_t.value is not right ,need test it 
    write_register(self, reg_t.addr, &reg_t.value, reg_t.size);
    // set the single channel
    select_single_channel(self, ch);
    // set samplerate
    set_sample_rate(self, ch, rate);
    delay_us = (uint32_t) ((1000000.0 / AD7175_rates_table[self->rate].rate) * 0.5);
    printf("delay_us: %d\n", delay_us);
    printf("set sample rate: %02x\n", rate);
    printf("set sample rate: %02x\n", self->rate);
    //set continuse read mode
    wd_data_16.value = 0x0000;
    // CONTRED and DATA_STAT enabled 0x00c0
    // wd_data_16.value = ((wd_data_16.value & 0xff0f) | 0x00c0);
    wd_data_16.value = ((wd_data_16.value & 0xff0f) | 0x0080);
    wd_data_16.value &= ~CLOCKSEL_MASK;
    wd_data_16.value |= self->clock;
    reg_t = AD7175_regs[Interface_Mode_Register];
    // write_register(self, reg_t.addr, &wd_data_16, reg_t.size);
    // reverse(reg_data, len);
    // memcpy(&wd_data[1], reg_data, len);
    wd_data[0] = reg_t.addr;
    wd_data[1] = wd_data_16.reg[1];
    wd_data[2] = wd_data_16.reg[0];
    //# cs low and begin to start continuse read
    mp_hal_pin_write(self->cs, 0);
    spi_proto.transfer(self->spi, 3, wd_data, NULL);
    for (int i=0; i< nums; i++){
        //default timeout is 500ms
        timeout = delay_us * 3;
        while(timeout){
            if (mp_hal_pin_read(self->status) == 0){
                spi_proto.transfer(self->spi, 3, &raw_data[i].reg[0], &raw_data[i].reg[0]);
                break;
            }
            mp_hal_delay_us(1);
            timeout--;
        }
        if (!timeout){
            goto ERROR;
        }
        continue;
    }
    while(!mp_hal_pin_read(self->status));
    reset(self);
ERROR:
    // reg_t = AD7175_regs[Data_Register];

    // read_register(self, reg_t.addr, wd_data, reg_t.size);
    for (int i=0; i< nums; i++){
        printf("voltage0: %f\n", value_2_mvolt(self, (float)(raw_data[i].reg[0]<<16|raw_data[i].reg[1]<<8|raw_data[i].reg[2])));
        // printf("%d: %02d-%02d-%02d-%02d\n", i, raw_data[i].reg[0],raw_data[i].reg[1],raw_data[i].reg[2],raw_data[i].reg[3]);
    }
    m_del(c_u32_t, raw_data, nums);
    mp_hal_pin_write(self->cs, 1);
    if (!timeout){
        mp_raise_ValueError(MP_ERROR_TEXT("datalogger is timeout"));
    }
}

//only for test
void cs_test(ad7175_handler *self)
{
    mp_hal_pin_write(self->cs, 0);
    mp_hal_pin_write(self->cs, 1);
}

uint8_t status_test(ad7175_handler *self)
{
    return mp_hal_pin_read(self->status);
}

// mechine hw register
mp_obj_t machine_hw_ad7175_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *all_args) {
    enum {ARG_id, ARG_cs, ARG_status, ARG_baudrate, ARG_polarity, ARG_phase};
    static const mp_arg_t allowed_args[] = {
        {MP_QSTR_id, MP_ARG_REQUIRED | MP_ARG_INT , {.u_int = 1}},
        {MP_QSTR_cs, MP_ARG_REQUIRED | MP_ARG_OBJ , {.u_obj = MP_OBJ_NULL}},
        {MP_QSTR_status, MP_ARG_REQUIRED | MP_ARG_OBJ , {.u_obj = MP_OBJ_NULL}},
        {MP_QSTR_baudrate, MP_ARG_INT , {.u_int = 5000000}},
        {MP_QSTR_polarity, MP_ARG_INT, {.u_int = 1} },
        {MP_QSTR_phase,  MP_ARG_INT, {.u_int = 1} },
    };
    mp_arg_val_t args[MP_ARRAY_SIZE(allowed_args)];
    mp_arg_parse_all_kw_array(n_args, n_kw, all_args, MP_ARRAY_SIZE(allowed_args), allowed_args, args);
    ad7175_handler *self = m_new_obj(ad7175_handler);
    self->base.type = &ad7175_type;
    self->spi = m_new_obj(spi_proto_cfg_t);
    if (args[ARG_cs].u_obj == MP_OBJ_NULL || args[ARG_status].u_obj == MP_OBJ_NULL) {
        mp_raise_ValueError(MP_ERROR_TEXT("explicit choice of cs/status is not implemented"));
    }
    hw_spi_init(self->spi, args[ARG_id].u_int, args[ARG_baudrate].u_int, args[ARG_polarity].u_int, args[ARG_phase].u_int);
    ad7175_init(self, mp_hal_get_pin_obj(args[ARG_cs].u_obj), mp_hal_get_pin_obj(args[ARG_status].u_obj));
    return MP_OBJ_FROM_PTR(self);
}


STATIC mp_obj_t mpy_ic_init(mp_obj_t self_in)
{    
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    ic_init(self);
    // printf("address: %02x\n", self->addr);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(mpy_ic_init_obj, mpy_ic_init);

STATIC mp_obj_t mpy_ready(mp_obj_t self_in, mp_obj_t times)
{   
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    int int_times = mp_obj_get_int(times);
    printf("int_times: %d\n", int_times);
    printf("*******************************\n");
    for (int i=0; i< int_times; i++)
    {
        wait_for_ready_no_timeout(self);
    }
    // printf("address: %02x\n", self->addr);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_2(mpy_ready_obj, mpy_ready);



STATIC mp_obj_t mpy_id_detect(mp_obj_t self_in)
{   
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    // printf("address: %02x\n", self->addr);
    return mp_obj_new_bool( !id_detect(self, 5) ? true : false);
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(mpy_id_detect_obj, mpy_id_detect);

STATIC mp_obj_t mpy_status_test(mp_obj_t self_in, mp_obj_t times)
{   
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    int int_times = mp_obj_get_int(times);
    uint8_t a;
    for (int i=0; i< int_times; i++)
    {
        a = status_test(self);
    }
    printf("status: %d\n", a);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_2(mpy_status_test_obj, mpy_status_test);


STATIC mp_obj_t mpy_reset(mp_obj_t self_in)
{    
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    reset(self);
    // printf("address: %02x\n", self->addr);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(mpy_reset_obj, mpy_reset);

STATIC mp_obj_t mpy_get_sample_rate(mp_obj_t self_in)
{    
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    float rate = get_sample_rate(self);    
    return mp_obj_new_float(rate);
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(mpy_get_sample_rate_obj, mpy_get_sample_rate);

STATIC mp_obj_t mpy_set_sample_rate(mp_obj_t self_in, mp_obj_t ch, mp_obj_t rate)
{   
    sample_rate_t t;
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    AD7175_channel channel = mp_obj_get_int(ch);
    t = search_sample_rate(self, mp_obj_get_int(rate));
    set_sample_rate(self, channel, t.value);
    printf("sample_rate: %f\n", get_sample_rate(self));
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_3(mpy_set_sample_rate_obj, mpy_set_sample_rate);

STATIC mp_obj_t mpy_read_volt(mp_obj_t self_in, mp_obj_t ch)
{    
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    AD7175_channel channel = mp_obj_get_int(ch);
    float value = read_volt(self, channel);
    return mp_obj_new_float(value);
}
STATIC MP_DEFINE_CONST_FUN_OBJ_2(mpy_read_volt_obj, mpy_read_volt);


STATIC mp_obj_t mpy_datalogger(mp_obj_t self_in, mp_obj_t ch, mp_obj_t nums)
{    
    ad7175_handler *self = MP_OBJ_TO_PTR(self_in);
    AD7175_channel channel = mp_obj_get_int(ch);
    sample_rate_t t;
    t = search_sample_rate(self, 125000);
    datalogger(self, channel, t.value, mp_obj_get_int(nums));
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_3(mpy_datalogger_obj, mpy_datalogger);




STATIC const mp_rom_map_elem_t ad7175_locals_dict_table[] = {
    { MP_ROM_QSTR(MP_QSTR___name__), MP_ROM_QSTR(MP_QSTR_ad7175) },
    { MP_ROM_QSTR(MP_QSTR_ic_init), MP_ROM_PTR(&mpy_ic_init_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_reset), MP_ROM_PTR(&mpy_reset_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_get_rate), MP_ROM_PTR(&mpy_get_sample_rate_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_set_rate), MP_ROM_PTR(&mpy_set_sample_rate_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_read_volt), MP_ROM_PTR(&mpy_read_volt_obj)},    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_datalogger), MP_ROM_PTR(&mpy_datalogger_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_ready), MP_ROM_PTR(&mpy_ready_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_id_detect), MP_ROM_PTR(&mpy_id_detect_obj) },    //添加的DICT里面去
    { MP_ROM_QSTR(MP_QSTR_status), MP_ROM_PTR(&mpy_status_test_obj) },    //添加的DICT里面去
};

//这个定义字典的宏定义
STATIC MP_DEFINE_CONST_DICT(ad7175_locals_dict, ad7175_locals_dict_table);


const mp_obj_type_t ad7175_type = {
    .base={ &mp_type_type }, 
    .name = MP_QSTR_ad7175,
    .make_new=machine_hw_ad7175_make_new,       //这个是我们新添加的make new属性
    .locals_dict = (mp_obj_dict_t*)&ad7175_locals_dict,
};

MP_REGISTER_MODULE(MP_QSTR_ad7175, ad7175_type, 1);
